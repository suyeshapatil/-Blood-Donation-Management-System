package com.bdms.service;

import java.util.List;

import com.bdms.entity.Donor;

public interface DonorService {

    Donor saveDonor(Donor donor);

    List<Donor> getAllDonors();

    Donor getDonorById(Long id);

    Donor updateDonor(Long id, Donor donor);

    void deleteDonor(Long id);
}