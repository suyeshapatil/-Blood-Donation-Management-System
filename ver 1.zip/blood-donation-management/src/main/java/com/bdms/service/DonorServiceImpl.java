package com.bdms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bdms.entity.Donor;
import com.bdms.repository.DonorRepository;

@Service
public class DonorServiceImpl implements DonorService {

    @Autowired
    private DonorRepository donorRepository;

    @Override
    public Donor saveDonor(Donor donor) {
        return donorRepository.save(donor);
    }

    @Override
    public List<Donor> getAllDonors() {
        return donorRepository.findAll();
    }

    @Override
    public Donor getDonorById(Long id) {
        return donorRepository.findById(id).orElse(null);
    }

    @Override
    public Donor updateDonor(Long id, Donor donor) {

        Donor existingDonor = donorRepository.findById(id).orElse(null);

        if (existingDonor != null) {
            existingDonor.setDonorName(donor.getDonorName());
            existingDonor.setAge(donor.getAge());
            existingDonor.setGender(donor.getGender());
            existingDonor.setBloodGroup(donor.getBloodGroup());
            existingDonor.setPhone(donor.getPhone());
            existingDonor.setEmail(donor.getEmail());
            existingDonor.setAddress(donor.getAddress());

            return donorRepository.save(existingDonor);
        }

        return null;
    }

    @Override
    public void deleteDonor(Long id) {
        donorRepository.deleteById(id);
    }
}