package com.bdms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bdms.entity.Hospital;
import com.bdms.repository.HospitalRepository;

@Service
public class HospitalService {
	
	@Autowired
    private HospitalRepository repo;

    public Hospital saveHospital(Hospital hospital) {
        return repo.save(hospital);
    }

    public List<Hospital> getAllHospitals() {
        return repo.findAll();
    }

}
