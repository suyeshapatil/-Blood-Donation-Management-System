package com.bdms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bdms.entity.User;
import com.bdms.repository.UserRepository;

@Service
public class UserService
{
    @Autowired
    UserRepository repo;

    public User saveUser(User user)
    {
        return repo.save(user);
    }

    public List<User> getAllUsers()
    {
        return repo.findAll();
    }

    public User findByEmail(String email)
    {
        return repo.findByEmail(email);
    }
}