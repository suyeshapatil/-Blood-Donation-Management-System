package com.bdms.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bdms.entity.BloodRequest;
import com.bdms.repository.BloodRequestRepository;


@Service
public class BloodRequestService {
	
	@Autowired
    private BloodRequestRepository bloodRequestRepository;

    public BloodRequest saveBloodRequest(BloodRequest bloodRequest) {
        return bloodRequestRepository.save(bloodRequest);
    }

    public List<BloodRequest> getAllBloodRequests() {
        return bloodRequestRepository.findAll();
    }

}
