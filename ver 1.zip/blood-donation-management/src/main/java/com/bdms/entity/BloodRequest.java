package com.bdms.entity;




import java.time.LocalDateTime;

import jakarta.persistence.*;

@Entity
@Table(name = "blood_requests")
public class BloodRequest {
	

	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long requestId;

	    @ManyToOne
	    @JoinColumn(name = "hospital_id")
	    private Hospital hospital;

	    private String patientName;

	    private String bloodGroup;

	    private Integer unitsRequired;

	    private String city;

	    private String urgencyLevel;

	    private String requestStatus;

	    private LocalDateTime createdAt;

	    public BloodRequest() {
	    }

	    public Long getRequestId() {
	        return requestId;
	    }

	    public void setRequestId(Long requestId) {
	        this.requestId = requestId;
	    }

	    public Hospital getHospital() {
	        return hospital;
	    }

	    public void setHospital(Hospital hospital) {
	        this.hospital = hospital;
	    }

	    public String getPatientName() {
	        return patientName;
	    }

	    public void setPatientName(String patientName) {
	        this.patientName = patientName;
	    }

	    public String getBloodGroup() {
	        return bloodGroup;
	    }

	    public void setBloodGroup(String bloodGroup) {
	        this.bloodGroup = bloodGroup;
	    }

	    public Integer getUnitsRequired() {
	        return unitsRequired;
	    }

	    public void setUnitsRequired(Integer unitsRequired) {
	        this.unitsRequired = unitsRequired;
	    }

	    public String getCity() {
	        return city;
	    }

	    public void setCity(String city) {
	        this.city = city;
	    }

	    public String getUrgencyLevel() {
	        return urgencyLevel;
	    }

	    public void setUrgencyLevel(String urgencyLevel) {
	        this.urgencyLevel = urgencyLevel;
	    }

	    public String getRequestStatus() {
	        return requestStatus;
	    }

	    public void setRequestStatus(String requestStatus) {
	        this.requestStatus = requestStatus;
	    }

	    public LocalDateTime getCreatedAt() {
	        return createdAt;
	    }

	    public void setCreatedAt(LocalDateTime createdAt) {
	        this.createdAt = createdAt;
	    }

}
