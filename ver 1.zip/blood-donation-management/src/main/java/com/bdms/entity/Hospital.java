package com.bdms.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.*;

@Entity
@Table(name = "hospitals")
public class Hospital {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long hospitalId;

	    private String hospitalName;

	    private String registrationNo;

	    private String email;

	    private String contactNo;

	    private String city;

	    private String address;

	    private Boolean verified;

	    public Hospital() {

	    }

	    public Long getHospitalId() {
	        return hospitalId;
	    }

	    public void setHospitalId(Long hospitalId) {
	        this.hospitalId = hospitalId;
	    }

	    public String getHospitalName() {
	        return hospitalName;
	    }

	    public void setHospitalName(String hospitalName) {
	        this.hospitalName = hospitalName;
	    }

	    public String getRegistrationNo() {
	        return registrationNo;
	    }

	    public void setRegistrationNo(String registrationNo) {
	        this.registrationNo = registrationNo;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }

	    public String getContactNo() {
	        return contactNo;
	    }

	    public void setContactNo(String contactNo) {
	        this.contactNo = contactNo;
	    }

	    public String getCity() {
	        return city;
	    }

	    public void setCity(String city) {
	        this.city = city;
	    }

	    public String getAddress() {
	        return address;
	    }

	    public void setAddress(String address) {
	        this.address = address;
	    }

	    public Boolean getVerified() {
	        return verified;
	    }

	    public void setVerified(Boolean verified) {
	        this.verified = verified;
	    }

}
