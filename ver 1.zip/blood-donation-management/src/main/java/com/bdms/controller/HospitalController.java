package com.bdms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import com.bdms.entity.Hospital;
import com.bdms.service.HospitalService;

@Controller

public class HospitalController {
	
	@Autowired
    private HospitalService service;

//    @PostMapping
//    public Hospital saveHospital(@RequestBody Hospital hospital) {
//        return service.saveHospital(hospital);
//    }
    
    @PostMapping("/saveHospital")
    public String saveHospitalForm(Hospital hospital) {

        service.saveHospital(hospital);

        return "redirect:/";
    }
    @GetMapping("/hospital-register")
    public String showHospitalRegisterPage() {
        return "hospital-register";
    }

//    @GetMapping
//    public List<Hospital> getAllHospitals() {
//        return service.getAllHospitals();
//    }

}
