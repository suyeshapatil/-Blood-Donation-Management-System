package com.bdms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/register")
    public String register() {
        return "register";
    }
    
    @GetMapping("/hospital/register")
    public String hospitalRegister() {
        return "hospital-register";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/donor/dashboard")
    public String donorDashboard() {
        return "donor-dashboard";
    }
}