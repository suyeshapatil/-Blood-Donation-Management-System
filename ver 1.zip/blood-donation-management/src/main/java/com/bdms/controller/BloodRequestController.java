package com.bdms.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.ui.Model;

import org.springframework.ui.Model;

import com.bdms.entity.BloodRequest;
import com.bdms.service.BloodRequestService;

@Controller
public class BloodRequestController {
	
	@Autowired
    private BloodRequestService bloodRequestService;

    @GetMapping("/blood-request")
    public String showBloodRequestForm() {
        return "blood-request";
    }

    @PostMapping("/blood-request")
    public String saveBloodRequest(BloodRequest bloodRequest) {

        bloodRequest.setRequestStatus("OPEN");

        bloodRequestService.saveBloodRequest(bloodRequest);

        return "redirect:/blood-request";
    }
    
    @GetMapping("/blood-requests")
    public String viewBloodRequests(Model model) {

        List<BloodRequest> requests =
                bloodRequestService.getAllBloodRequests();

        model.addAttribute("requests", requests);

        return "view-bloodrequests";
    }

}
