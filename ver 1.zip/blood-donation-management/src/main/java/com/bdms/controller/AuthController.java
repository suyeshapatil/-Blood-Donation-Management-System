package com.bdms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.bdms.entity.User;
import com.bdms.service.UserService;

@Controller
public class AuthController {

    @Autowired
    UserService service;
    
    @PostMapping("/saveUser")
    public String saveUser(User user) {

        service.saveUser(user);

        return "login";
    }

    @PostMapping("/validateLogin")
    public String login( @RequestParam String email, @RequestParam String password) {

        User user = service.findByEmail(email);

        if(user != null &&
           user.getPassword().equals(password)) {

            if(user.getRole().equals("DONOR")) {
                return "redirect:/donor/dashboard";
            }

            if(user.getRole().equals("HOSPITAL")) {
                return "redirect:/hospital/dashboard";
            }

            if(user.getRole().equals("ADMIN")) {
                return "redirect:/admin/dashboard";
            }
        }

        return "login";
    }
}