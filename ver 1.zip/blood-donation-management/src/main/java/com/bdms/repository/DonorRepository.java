package com.bdms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bdms.entity.Donor;

@Repository
public interface DonorRepository extends JpaRepository<Donor, Long> {

}