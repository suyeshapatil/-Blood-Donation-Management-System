package com.bdms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bdms.entity.BloodRequest;

public interface BloodRequestRepository  extends JpaRepository<BloodRequest, Long>{

}
