package com.bdms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bdms.entity.Hospital;

public interface HospitalRepository extends JpaRepository<Hospital, Long>{

}
